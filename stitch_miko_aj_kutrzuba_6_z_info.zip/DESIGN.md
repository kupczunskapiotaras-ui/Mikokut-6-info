---
name: Visionary AI Education
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434656'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#747688'
  outline-variant: '#c4c5d9'
  surface-tint: '#124af0'
  primary: '#0040e0'
  on-primary: '#ffffff'
  primary-container: '#2e5bff'
  on-primary-container: '#efefff'
  inverse-primary: '#b8c3ff'
  secondary: '#8127cf'
  on-secondary: '#ffffff'
  secondary-container: '#9c48ea'
  on-secondary-container: '#fffbff'
  tertiary: '#006052'
  on-tertiary: '#ffffff'
  tertiary-container: '#007b6a'
  on-tertiary-container: '#b1ffec'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dde1ff'
  primary-fixed-dim: '#b8c3ff'
  on-primary-fixed: '#001356'
  on-primary-fixed-variant: '#0035be'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb7ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6900b3'
  tertiary-fixed: '#26fedc'
  tertiary-fixed-dim: '#00dfc1'
  on-tertiary-fixed: '#00201a'
  on-tertiary-fixed-variant: '#005144'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-xl:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-xl-mobile:
    fontFamily: Montserrat
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
Ten system projektowy łączy rygorystyczny minimalizm z energetyczną, futurystyczną paletą barw, aby stworzyć platformę edukacyjną poświęconą przyszłości sztucznej inteligencji. Celem jest wywołanie poczucia optymizmu, innowacji i przejrzystości. 

Stylistyka opiera się na **Modern Minimalism** wzbogaconym o **Vibrant Accents**. Wykorzystujemy dużą ilość wolnej przestrzeni (whitespace), aby ułatwić przyswajanie skomplikowanych treści technicznych, jednocześnie stosując nasycone kolory neonowe do wyróżnienia kluczowych interakcji i pojęć. Całość sprawia wrażenie lekkiej, napowietrzonej i niezwykle nowoczesnej, unikając przy tym mrocznych, dystopijnych skojarzeń często łączonych z technologią AI.

## Colors
Paleta kolorystyczna jest odważna i progresywna. Dominujący **Electric Blue** buduje zaufanie i profesjonalizm, podczas gdy **Neon Purple** i **Soft Mint** wprowadzają element futurystycznej energii. **Warm Orange** służy jako kolor akcentowy dla najważniejszych wezwań do działania (CTA).

- **Primary (Electric Blue):** Główny kolor nawigacji i interakcji.
- **Secondary (Neon Purple):** Używany do gradientów i wyróżniania sekcji tematycznych.
- **Tertiary (Soft Mint):** Kolor sukcesu, postępu i świeżości.
- **Accent (Warm Orange):** Krytyczne punkty konwersji i powiadomienia.
- **Background:** Jasnoszary/biały (#F8FAFC), zapewniający maksymalny kontrast dla nasyconych barw.

## Typography
Typografia łączy geometryczną siłę fontu **Montserrat** z funkcjonalną czystością fontu **Inter**.

Nagłówki (Montserrat) powinny być renderowane z ciasnym światłem międzyliterowym (letter-spacing), aby wzmocnić ich nowoczesny charakter. Tekst ciągły (Inter) stawia na czytelność – stosujemy zwiększoną interlinię (line-height), aby ułatwić czytanie długich artykułów edukacyjnych. Wszystkie etykiety i małe teksty pomocnicze korzystają z Inter w odmianie SemiBold, co zapewnia hierarchię wizualną nawet przy małych rozmiarach.

## Layout & Spacing
System opiera się na 12-kolumnowej siatce (grid) z dużymi marginesami, co potęguje wrażenie lekkości. 

- **Siatka:** 12 kolumn na desktopie, 4 kolumny na mobile.
- **Odstępy:** Wykorzystujemy system oparty na wielokrotności 8px. 
- **Whitespace:** Pomiędzy sekcjami (pionowo) stosujemy agresywne odstępy (np. 80px - 120px), aby odseparować różne wątki edukacyjne.
- **Karty:** Kontenery treści mają zdefiniowany padding (32px na desktopie), tworząc spójny rytm wewnętrzny.

## Elevation & Depth
W tym systemie głębia jest subtelna, ale kluczowa dla budowania hierarchii. Zamiast ciężkich cieni, stosujemy **Ambient Shadows** – bardzo rozproszone, o niskim stopniu krycia (5-8%), z lekkim zabarwieniem kolorem głównym (Electric Blue).

Główne poziomy warstw:
1. **Poziom 0 (Tło):** Czyste #F8FAFC.
2. **Poziom 1 (Karty):** Białe tło z bardzo miękkim cieniem, sprawiające wrażenie lekko uniesionych nad powierzchnię.
3. **Poziom 2 (Hover/Interakcja):** Zwiększony rozmycie cienia (blur) oraz delikatne przesunięcie elementu w górę (translation), co sygnalizuje interaktywność.

## Shapes
Język kształtów jest przyjazny i organiczny. Zgodnie z wytycznymi, stosujemy wysoki stopień zaokrąglenia rogów (**2xl**), co zmiękcza technologiczny charakter tematyki AI i czyni platformę bardziej przystępną dla użytkownika.

Wszystkie główne komponenty (karty, pola wprowadzania, przyciski) korzystają z zaokrągleń o promieniu 1rem (16px) do 1.5rem (24px). Elementy dekoracyjne, takie jak kolorowe plamy w tle, powinny mieć formę miękkich, amorficznych kształtów (blobs).

## Components
Komponenty są sercem interakcji w tym systemie:

- **Przyciski (Buttons):**
  - *Primary:* Wypełnienie Electric Blue lub gradient (Electric Blue do Neon Purple), biały tekst, silnie zaokrąglone rogi.
  - *Secondary:* Outline w kolorze Electric Blue z przezroczystym tłem.
- **Karty (Cards):** Białe tło, zaokrąglenie 24px, subtelny cień. Karty edukacyjne mogą posiadać górny border (4px) w jednym z kolorów akcentowych (np. Mint dla 'Level: Beginner').
- **Pola tekstowe (Inputs):** Bardzo jasne tło, brak obramowania w stanie spoczynku, 16px zaokrąglenia. Po kliknięciu (focus) pojawia się 2px obramowanie w kolorze Electric Blue.
- **Tagi/Chips:** Małe, kolorowe elementy z niskim kontrastem tła (np. 10% nasycenia Neon Purple) i ciemniejszym tekstem w tym samym odcieniu.
- **Ikony:** Proste, liniowe (line-art), ale zawsze wielokolorowe. Używamy dwóch odcieni z palety (np. błękit i mięta) w jednej ikonie, aby podkreślić "vibrant" charakter systemu.